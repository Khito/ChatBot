Download and extract the Scotus dataset here:

```bash
# From this directory:
wget https://github.com/pender/chatbot-rnn/raw/master/data/scotus/scotus.bz2 && bzip2 -dk scotus.bz2 && rm scotus.bz2
```
